const functions = require("@google-cloud/functions-framework");

const { exec } = require("child_process");
const https = require("https");
const fs = require("fs");
const AdmZip = require("adm-zip");

const NODE_WALLET_KEY = "<private-key-here>"; // private key (delegated private key recommended)
const NODE_WALLET_ADDRESS = "<wallet-address>"; // public address where node keys are held

functions.http("claimNodeRewards", (req, res) => {
  const runNode = (zipFilePath) => {
    const zip = new AdmZip(zipFilePath);
    zip.extractAllTo("/tmp", true);
    runExec(
      `chmod +x /tmp/guardian-cli-linux && chmod -R +x /tmp/validation-engine`,
      ""
    ).then(() => {
      claimRewards().then((result) => {
        console.log("Claim Ran");
      });
    });
  };

  const claimRewards = () => {
    return runExec(
      `./guardian-cli-linux guardian owned-node-keys ${NODE_WALLET_ADDRESS}`,
      "/tmp"
    ).then((stdout) => {
      const keysRef = stdout.split("\n");
      keysRef.pop();
      const keys = keysRef.join(",").replace(/n/g, "");
      if (!keys) {
        console.log(
          `No node keys found for the following address: ${NODE_WALLET_ADDRESS}, can't provide earned rewards.`
        );
        return "N/A";
      }
      return runExec(
        `./guardian-cli-linux guardian reward-to-claim ${keys}`,
        "/tmp"
      ).then((stdout) => {
        const awardsRef = stdout.split("\n");
        awardsRef.pop();
        const awardsTotal = awardsRef.reduce((total, item) => {
          value = item.substring(item.indexOf("): ") + 3);
          total += BigInt(value);
          return total;
        }, 0n);
        let sumString = awardsTotal.toString();
        // If the sum has fewer than 18 digits, pad it with zeroes
        if (sumString.length < 18) {
          sumString = sumString.padStart(18, "0");
        }
        const decRef = sumString.length - 18;
        sumString =
          sumString.substring(0, decRef) + "." + sumString.substring(decRef);
        console.log(
          `Total Unclaimed Rewards prior to this run: ${parseFloat(
            sumString
          ).toFixed(3)}`
        );
        return runExec(
          `./guardian-cli-linux guardian claim-rewards --node-key-ids ${keys} ${NODE_WALLET_KEY}`,
          "/tmp"
        )
          .catch((err) => {
            console.log(err);
            return false;
          })
          .then((stdout) => {
            console.log(stdout);
            return true;
          });
      });
    });
  };

  const runExec = (command, wd) => {
    return new Promise((resolve, reject) => {
      exec(command, { cwd: wd }, (error, stdout, stderr) => {
        if (error) {
          reject(error.message);
        }
        if (stderr) {
          reject(stderr);
        }
        resolve(stdout);
      });
    });
  };

  const downloadFile = (fileUrl, filePath) => {
    const file = fs.createWriteStream(filePath);

    const request = https.get(fileUrl, (response) => {
      if (
        response.statusCode >= 300 &&
        response.statusCode < 400 &&
        response.headers.location
      ) {
        // Redirect detected, recursively call downloadFile with the new location
        console.log("Redirecting to:", response.headers.location);
        downloadFile(response.headers.location, filePath);
      } else {
        response.pipe(file);
        file.on("finish", () => {
          file.close();
          console.log("Download complete");
          //listFilesInDirectory();
          runNode(filePath);
          // Now you can handle the downloaded file as needed
        });
      }
    });

    request.on("error", (err) => {
      console.error("Error downloading file:", err);
      res.status(500).send(`Error downloading file: ${err.message}`);
      return;
    });
  };

  const zipFilePath = "/tmp/node.zip"; // Create the path to the ZIP file in the /tmp directory

  downloadFile(
    "https://github.com/HYCHAIN/guardian-node-software/releases/download/0.0.1/guardian-cli-linux-v0.0.1.zip",
    zipFilePath
  );
});
