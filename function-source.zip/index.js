const functions = require("@google-cloud/functions-framework");

const { exec } = require("child_process");
const https = require("https");
const fs = require("fs");
const AdmZip = require("adm-zip");

const NODE_WALLET_KEY =
  "<private-key-here>";

functions.http("runGuardianNode", (req, res) => {
  const runNode = (zipFilePath) => {
    const zip = new AdmZip(zipFilePath);
    zip.extractAllTo("/tmp", true);
    console.log("done");

  exec(`chmod +x /tmp/guardian-cli-linux && chmod -R +x /tmp/validation-engine`, (error, stdout, stderr) => {
      if (error) {
        res.status(500).send(`chmod error: ${error.message}`);
        return;
      }
      // Run the guardian node software
      exec(
        `./guardian-cli-linux guardian run ${NODE_WALLET_KEY}`,
        { cwd: "/tmp" },
        (error, stdout, stderr) => {
          if (error) {
            console.error(`exec error: ${error}`);
            res.status(500).send(`exec error: ${error.message}`);
            return;
          }
          console.log(`stdout: ${stdout}`);
          res.status(200).send("Guardian node run successfully.");
        }
      );
    });
  };

  const downloadFile = (fileUrl, filePath) => {
    const file = fs.createWriteStream(filePath);

    const request = https.get(fileUrl, (response) => {
      if (
        response.statusCode >= 300 &&
        response.statusCode < 400 &&
        response.headers.location
      ) {
        // Redirect detected, recursively call downloadFile with the new location
        console.log("Redirecting to:", response.headers.location);
        downloadFile(response.headers.location, filePath);
      } else {
        response.pipe(file);
        file.on("finish", () => {
          file.close();
          console.log("Download complete");
          //listFilesInDirectory();
          runNode(filePath);
          // Now you can handle the downloaded file as needed
        });
      }
    });

    request.on("error", (err) => {
      console.error("Error downloading file:", err);
      res.status(500).send(`Error downloading file: ${err.message}`);
      return;
    });
  };

  const zipFilePath = "/tmp/node.zip"; // Create the path to the ZIP file in the /tmp directory

  downloadFile(
    "https://github.com/HYCHAIN/guardian-node-software/releases/download/0.0.1/guardian-cli-linux-v0.0.1.zip",
    zipFilePath
  );
});

const listFilesInDirectory = () => {
  const directoryPath = "/tmp"; // Specify the directory path

  // Read the contents of the directory
  fs.readdir(directoryPath, (err, files) => {
    if (err) {
      console.error("Error reading directory:", err);
      res.status(500).send("Error reading directory");
      return;
    }

    // Iterate through the files in the directory
    const fileDetails = files.map((file) => {
      const filePath = `${directoryPath}/${file}`;
      const stats = fs.statSync(filePath);
      return {
        name: file,
        sizeInBytes: stats.size,
      };
    });

    // Log the file details
    console.log("Files in directory:");
    fileDetails.forEach((file) => {
      console.log(`${file.name}: ${file.sizeInBytes} bytes`);
    });
  });
};
