const functions = require("@google-cloud/functions-framework");
const { exec } = require("child_process");
const https = require("https");
const fs = require("fs");
const AdmZip = require("adm-zip");

const NODE_WALLET_KEY =
  "<private-key-here>";

functions.http("runGuardianNode", async (req, res) => {
  try {
    const zipFilePath = await downloadFile(
      "https://github.com/HYCHAIN/guardian-node-software/releases/download/0.0.1/guardian-cli-linux-v0.0.1.zip",
      "/tmp/node.zip"
    );

    await extractAndRunNode(zipFilePath);

    res.status(200).send("Guardian node run successfully.");
  } catch (error) {
    console.error("Error:", error);
    res.status(500).send(`Error: ${error.message}`);
  }
});

async function downloadFile(fileUrl, filePath) {
  return new Promise((resolve, reject) => {
    const file = fs.createWriteStream(filePath);

    https.get(fileUrl, (response) => {
      if (response.statusCode >= 300 && response.statusCode < 400 && response.headers.location) {
        console.log("Redirecting to:", response.headers.location);
        return downloadFile(response.headers.location, filePath);
      }

      response.pipe(file);
      file.on("finish", () => {
        file.close();
        console.log("Download complete");
        resolve(filePath);
      });
    }).on("error", (err) => {
      console.error("Error downloading file:", err);
      reject(err);
    });
  });
}

async function extractAndRunNode(zipFilePath) {
  return new Promise((resolve, reject) => {
    const zip = new AdmZip(zipFilePath);
    zip.extractAllTo("/tmp", true);
    console.log("Extraction done");

    exec(`chmod +x /tmp/guardian-cli-linux && chmod -R +x /tmp/validation-engine`, { cwd: "/tmp" }, (error, stdout, stderr) => {
      if (error) {
        console.error(`chmod error: ${error}`);
        reject(error);
      }

      exec(`./guardian-cli-linux guardian run ${NODE_WALLET_KEY}`, { cwd: "/tmp" }, (error, stdout, stderr) => {
        if (error) {
          console.error(`exec error: ${error}`);
          reject(error);
        }
        console.log(`stdout: ${stdout}`);
        resolve();
      });
    });
  });
}
